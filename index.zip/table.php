<?php

// check to see if state_id has been submitted
if(isset($_POST['stateid']))
{
    $state_id = $_POST['stateid'];
}
// if it is not set, add something in place.
else
{
    $state_id = "1";
}

// query goes here - ask for the ID
$query = "SELECT name, id from state where id = " . $state_id;

$results = $con->query($query);
while($rs=$results->fetch_assoc()) {

    //... create table with all content;

}

?>